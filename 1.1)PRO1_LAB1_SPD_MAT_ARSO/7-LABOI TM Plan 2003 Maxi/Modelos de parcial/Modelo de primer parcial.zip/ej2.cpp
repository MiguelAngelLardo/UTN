#include <iostream>
using namespace std;
int main(){
    int d1, d2, mayor, menor, dif, puntaje=0;
    cout << "Dado 1: ";
    cin >> d1;
    cout << "Dado 2: ";
    cin >> d2;
    if (d1 > d2){
        mayor = d1;
        menor = d2;
    }
    else{
        mayor = d2;
        menor = d1;
    }
    dif = mayor - menor;
    if (dif >= 2 && dif <= 4){
        puntaje = 10;
    }
    cout << "Puntaje obtenido: " << puntaje << endl;
    return 0;
}

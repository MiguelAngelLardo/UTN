#include <iostream>
using namespace std;
int main(){
    int afiliado, edad;
    char genero;
    float temp;
    ///A
    int maxAfiliado;
    float maxTemp = 0;
    ///B
    int sumaEdad = 0;
    int cantMujeres = 0;
    float promedio;
    ///C
    int hipo, normal, fiebre, total;
    float p_hipo, p_normal, p_fiebre;
    hipo=normal=fiebre=0;

    cout << "Nro de Afiliado: ";
    cin >> afiliado;

    while (afiliado != 0){
        cout << "Edad: ";
        cin >> edad;
        cout << "Genero: ";
        cin >> genero;
        cout << "Temperatura: ";
        cin >> temp;

        ///A
        if (genero == 'M' || genero == 'm'){
            if (temp > maxTemp){
                maxTemp = temp;
                maxAfiliado = afiliado;
            }

        }
        ///B
        if (genero == 'F' || genero == 'f'){
            cantMujeres++;
            sumaEdad+=edad;
        }
        ///C
        if (temp < 35){
            hipo++;
        }
        else{
            if(temp > 37.5){
                fiebre++;
            }
            else{
                normal++;
            }
        }

        cout << "Nro de Afiliado: ";
        cin >> afiliado;        
    }
    cout << endl << "PUNTO A" << endl;
    if (maxTemp == 0){
        cout << "No hubo afiliados de genero masculino." << endl;
    }
    else{
        cout << "El afiliado " << maxAfiliado << " tuvo la mayor temperatura de los masculinos: " << maxTemp << endl;
    }
    cout << endl << "PUNTO B" << endl;
    if (cantMujeres > 0){
        promedio = (float) sumaEdad/cantMujeres;
        cout << "Promedio de edad de las mujeres: " << promedio << endl;
    }
    else{
        cout << "No hubo mujeres." << endl;
    }
    cout << endl << "PUNTO C" << endl;
    total = hipo + fiebre + normal;
    p_hipo = (float) hipo*100/total;
    p_normal = (float) normal*100/total;
    p_fiebre = (float) fiebre*100/total;
    cout << "Hipotermia: % " << p_hipo << endl;
    cout << "Normal    : % " << p_normal << endl;
    cout << "Fiebre    : % " << p_fiebre << endl;
    return 0;
}
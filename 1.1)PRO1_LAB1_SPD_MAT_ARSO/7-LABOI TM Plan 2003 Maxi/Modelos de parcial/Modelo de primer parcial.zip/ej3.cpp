#include <iostream>
using namespace std;
int main(){
    int estacion, hora, i;
    float temp, mm;

    /// A
    float sumaM, sumaV, sumaN;
    int cM, cV, cN;
    sumaM=sumaV=sumaN=cM=cV=cN=0;
    /// B
    int b=0;
    /// C
    float tempMin;
    int horaMin;

    cout << "Estacion: ";
    cin >> estacion;

    while (estacion != 0){
        for(i=1; i<=3; i++){
            cout << "Hora: ";
            cin >> hora;
            cout << "Temperatura: ";
            cin >> temp;
            cout << "Milimetros de lluvia: ";
            cin >> mm;
            /// A
            if (hora >= 6 && hora <= 12){
                cM++;
                sumaM+=temp;
            }
            else{
                if(hora >= 13 && hora <= 19){
                    cV++;
                    sumaV+=temp;
                }
                else{
                    if(hora >= 20 && hora <= 23){
                        cN++;
                        sumaN+=temp;
                        ///B
                        if (mm == 0){
                            b++;
                        }

                    }
                }
            }
            /// C
            if (i == 1){
                tempMin = temp;
                horaMin = hora;
            }
            else{
                tempMin = temp;
                horaMin = hora;
            }
        }
        cout << endl << "PUNTO C " << endl;
        cout << "Estacion: " << estacion << endl;
        cout << "Temperatura minima: " << tempMin << endl;
        cout << "Hora: " << horaMin << endl << endl;

        cout << "Estacion: ";
        cin >> estacion;
    }
    cout << endl << "PUNTO A" << endl;
    if (cM > 0){
        cout << "Matutino: " << (float) sumaM/cM;
    }
    if (cV > 0){
        cout << "Vespertino: " << (float) sumaV/cV;
    }
    if (cN > 0){
        cout << "Nocturno: " << (float) sumaN/cN;
    }
    cout << endl;
    cout << endl << "PUNTO B" << endl;
    cout << "Registros nocturnos sin lluvia: " << b << endl;
    return 0;
}
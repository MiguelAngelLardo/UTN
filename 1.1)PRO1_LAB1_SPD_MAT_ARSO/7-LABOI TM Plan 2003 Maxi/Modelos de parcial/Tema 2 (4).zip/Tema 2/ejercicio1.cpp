#include <iostream>
using namespace std;

int main(){
  int cat1, cat2, cat3;
  int importe;

  cout << "CANTIDAD DE ATLETAS CAT1:";
  cin >> cat1;
  cout << "CANTIDAD DE ATLETAS CAT2:";
  cin >> cat2;
  cout << "CANTIDAD DE ATLETAS CAT3:";
  cin >> cat3;

  importe = cat1*120000+cat2*93000+cat3*102000;

  if (importe > 15000000){
    cout << "FONDOS INSUFICIENTES. SON NECESARIOS: $ ";
    cout << importe - 15000000;
  }
  else{
    cout << "FONDOS SUFICIENTES.";
  }

  return 0;
}

#include <iostream>
using namespace std;

int main(){
  int mun, i, loc, fe, fa;
  ///A
  int sfe;
  float prom;
  ///C
  int loc90=0;
  float porc;

  cout << "MUNICIPIO: ";
  cin >> mun;

  while (mun != 0){
    sfe=0;
    for (i=1; i<=3; i++){
      cout << endl << "LOCALIDAD: ";
      cin >> loc;
      cout << "FACTURAS EMITIDAS: ";
      cin >> fe;
      cout << "FACTURAS ABONADAS: ";
      cin >> fa;

      ///A
      sfe = sfe + fe;
      ///B
      porc = fa*100/fe;
      if (porc > 90){
        loc90++;
      }
    }
    cout << endl << "PUNTO A" << endl;
    cout << "PROMEDIO FE: ";
    prom = sfe/3;
    cout << prom;

    cout << endl << "MUNICIPIO: ";
    cin >> mun;
  }
  cout << endl << "PUNTO B" << endl;
  cout << "LOCALIDADES QUE ABONARON M�S DEL 90% DE FACT EMITIDAS: ";
  cout << loc90;

  return 0;
}

#include <iostream>
using namespace std;

int main(){
  bool continuar=true;
  int n, nant, c=0;

  ///A
  int mp=0;
  ///B
  int pi=0;

  while (continuar == true){
    cout << "NUMERO: ";
    cin >> n;
    c++;

    if (c>1){
      if (n == nant*2){
        continuar = false;
      }
    }
    nant = n;

    ///A
    if (n > 0){
      if (mp == 0 || n < mp){
        mp = n;
      }
    }
    ///B
    if (n%2 != 0){
      if (pi == 0){
        pi = n;
      }
    }

  }
  cout << "PUNTO A" << endl;
  if (mp == 0){
    cout << "NO HUBO POSITIVOS.";
  }
  else{
    cout << "MINIMO POSITIVO: " << mp;
  }

  cout << endl << endl "PUNTO B" << endl;
  if (pi == 0){
    cout << "NO HUBO IMPARES.";
  }
  else{
    cout << "PRIMER IMPAR: " << pi;
  }


  return 0;
}

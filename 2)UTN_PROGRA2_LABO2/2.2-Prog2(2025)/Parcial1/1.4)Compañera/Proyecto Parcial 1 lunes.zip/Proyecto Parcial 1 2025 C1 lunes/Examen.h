#ifndef EXAMEN_H_INCLUDED
#define EXAMEN_H_INCLUDED

class Examen{

   public:
   void Punto1();
   void Punto2();
   void Punto3();
   void EjemploDeListado();
};

#endif // EXAMEN_H_INCLUDED

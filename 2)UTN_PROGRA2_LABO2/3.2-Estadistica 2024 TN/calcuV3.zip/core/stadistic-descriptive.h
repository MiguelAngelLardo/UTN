#pragma once
#include <iostream>
#include <cstring>

class StadisticDescriptive
{
   private:
    double *_unsortedList;
    double *_valueList;
    double *_xi;
    double *_fi;
    double *_Fi;
    double *_Fr;
    double *_fr;
    size_t _sizeTable;
    double _Mo;
    double _Me;
    double _x;
    double _sampleDeviation;
    double _populationDeviation;
    double _sampleVariance;
    double _populationVariance;
    double _sampleCv;
    double _populationCV;

    size_t _size;

    void sortArray();
    void fillArray();
    void clearArray();
    void chargeMemory(int size);

   public:
    StadisticDescriptive();
    ~StadisticDescriptive();
    bool setData(std::string str);
    void setData(double d[], size_t s);
    void showValues();
    void showTable();
    bool setDataDual(std::string str);
    int getSize();
    double getUnsortedList(int i);
    double get_x();
    double getPopulationVariance();
    double getPopulationDesviation();
};

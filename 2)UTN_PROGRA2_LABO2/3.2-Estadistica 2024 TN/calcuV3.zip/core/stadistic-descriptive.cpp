#include "./stadistic-descriptive.h"
#include <iomanip> 

#include <algorithm>
#include <cmath>

StadisticDescriptive::StadisticDescriptive() {
   _unsortedList = nullptr;
   _valueList = nullptr;
   _fi = nullptr;
   _fr = nullptr;
   _Fi = nullptr;
   _Fr = nullptr;
   _xi = nullptr;
   _Mo = 0;
   _Me = 0;
   _sampleDeviation = 0;
   _populationDeviation = 0;
   _x = 0;
   _size = 0;
};

StadisticDescriptive::~StadisticDescriptive() {
   if (_valueList != nullptr) {
      delete[] _valueList;
   }
   if(this->_unsortedList != nullptr){
      delete[] this->_unsortedList;
   }
   clearArray();
}

void StadisticDescriptive::setData(double d[], size_t s) {
   chargeMemory(s);
   for (int i = 0; i < s; i++) {
      _valueList[i] = d[i];
   }
   fillArray();
};

bool StadisticDescriptive::setData(std::string str) {
   if (str.length() == 0) {
      return false;
   }
   std::string finalStr;
   for (char withoutSpace : str) {
      if (withoutSpace != ' ') {
         finalStr += withoutSpace;
      }
   }
   const char* c = finalStr.c_str();
   char* t1 = new char[2];
   t1[0] = str[str.length() - 1];
   t1[1] = '\0';
   const char* separator = t1;
   size_t len = strlen(c);
   int count = 0;
   for (int i = 0; i < len + 1; i++) {
      if (c[i] == separator[0]) {
         count++;
      }
   }
   if (count == 0) {
      return false;
   }
   chargeMemory(count);
   char* str_c = new char[strlen(c) + 1];
   strcpy(str_c, c);
   char* token = strtok(str_c, separator);
   for (int i = 0; i < _size; i++) {
      _valueList[i] = strtof(token, nullptr);
      token = strtok(nullptr, separator);
   }
   delete[] str_c;
   delete[] t1;
   fillArray();
   return true;
};

void StadisticDescriptive::showValues() {
   std::cout << "los valores son : " << std::endl;
   for (int i = 0; i < _size; i++) {
      std::cout << _valueList[i] << " ";
   }
   std::cout << std::endl;
};

void StadisticDescriptive::sortArray() {
   if (_valueList == nullptr) {
      return;
   }
   if(_unsortedList != nullptr){
      delete[] this->_unsortedList;
   }
   this->_unsortedList = new double[this->_size];
   for (int i = 0; i < _size;i++){
      this->_unsortedList[i] = this->_valueList[i];
   }
   std::stable_sort(_valueList, _valueList + _size);
}

void StadisticDescriptive::chargeMemory(int size) {
   if (_valueList != nullptr) {
      delete[] _valueList;
   }
   _valueList = new double[size];
   _size = size;
}

void StadisticDescriptive::fillArray() {
   if (_size == 0) {
      return;
   }
   sortArray();
   double* values = new double[_size]{0};
   double* count = new double[_size]{0};
   int index = 0;
   count[0] = 1;
   values[index] = _valueList[index];
   for (int i = 1; i < _size; i++) {
      if (_valueList[i] == values[index]) {
         count[index]++;
      } else {
         index++;
         values[index] = _valueList[i];
         count[index]++;
      }
   }
   _sizeTable = index + 1;
   clearArray();
   _xi = new double[_sizeTable];
   _fi = new double[_sizeTable];
   _Fi = new double[_sizeTable];
   _Fr = new double[_sizeTable];
   _fr = new double[_sizeTable];
   double sumfi = 0;
   for (int i = 0; i < _sizeTable; i++) {
      _xi[i] = values[i];
      _fi[i] = count[i];
      sumfi = sumfi + _fi[i];
   }
   delete[] values;
   delete[] count;
   _x = 0;
   _Mo = 0;
   int accTemp = 0;
   for (int i = 0; i < _sizeTable; i++) {
      _fr[i] = _fi[i] / sumfi;
      if (i == 0) {
         _Fi[i] = _fi[i];
      } else {
         _Fi[i] = _Fi[i - 1] + _fi[i];
      }
      _Fr[i] = _Fi[i] / sumfi;
      _x += (_xi[i] * _fi[i]) / sumfi;
      if(_fi[i]>accTemp){
         _Mo = _xi[i];
         accTemp = _fi[i];
      }
   }

   //
   double sumatoryTemp = 0;
   for (int i = 0; i < _size;i++){
      sumatoryTemp += (_valueList[i] - _x) * (_valueList[i] - _x);
   }
   _sampleDeviation = std::sqrt(sumatoryTemp / (sumfi-1));
   _populationDeviation = std::sqrt(sumatoryTemp / sumfi);
   _sampleVariance = (sumatoryTemp / (sumfi - 1));
   _populationVariance = (sumatoryTemp / sumfi);
   _sampleCv = (_sampleDeviation / _x) * 100;
   _populationCV = (_populationDeviation / _x) * 100;
   if(_size%2==0){
      _Me = (_valueList[_size/2]+_valueList[(_size/2)-1])/2;
   }
   else{
      _Me = _valueList[(_size / 2)];
   }
};

void StadisticDescriptive::clearArray() {
   if (_xi != nullptr) {
      delete[] _xi;
   }
   if (_fi != nullptr) {
      delete[] _fi;
   }
   if (_Fi != nullptr) {
      delete[] _Fi;
   }
   if (_Fr != nullptr) {
      delete[] _Fr;
   }
   if (_fr != nullptr) {
      delete[] _fr;
   }
};

void StadisticDescriptive::showTable() {
   std::cout << "Xi\tfi\tfr\t\tFi\t\tFr" << std::endl;
   for (int i = 0; i < _sizeTable; i++) {
      
      std::cout << _xi[i] << "\t";
      std::cout << _fi[i] << "\t";
      std::cout <<std::setprecision(4)<< _fr[i] << "\t\t";
      std::cout <<std::setprecision(4)<< _Fi[i] << "\t\t";
      std::cout <<std::setprecision(4)<< _Fr[i] << "\t\t";
      std::cout << std::endl;
   }

   std::cout << std::endl << "Modal Mo: " << _Mo ;
   std::cout << std::endl << "Mediana Me: " << _Me ;
   std::cout << std::endl << "Media o promedio X: " <<std::fixed<<std::setprecision(6)<< _x ;
   std::cout << std::endl;
   std::cout << std::endl << "Desvio muestral On-1: " <<std::fixed<<std::setprecision(6)<< _sampleDeviation ;
   std::cout << std::endl << "Varianza muestral V|X|s: " <<std::fixed<<std::setprecision(6)<< _sampleVariance ;
   std::cout << std::endl << "Coeficiente de variacion Muestral Cv%: " <<std::fixed<<std::setprecision(6)<< _sampleCv <<"%";
   std::cout << std::endl;
   std::cout << std::endl << "Desvio poblacional On: " <<std::fixed<<std::setprecision(6)<< _populationDeviation ;
   std::cout << std::endl << "Varianza Poblacional V|X|p: " <<std::fixed<<std::setprecision(6)<< _populationVariance ;
   std::cout << std::endl << "Coeficiente de variacion Poblacional Cv%: " <<std::fixed<<std::setprecision(6)<< _populationCV <<"%";
};

bool StadisticDescriptive::setDataDual(std::string str){
   if (str.length() == 0){
      return false;
   }
   std::string finalStr;
   for (char withoutSpace : str) {
      if (withoutSpace != ' ') {
         finalStr += withoutSpace;
      }
   }

   std::string strNum,strResult;
   int repeatNum = 0;
   int index,prev = 0;
   for (int i = 0; i < finalStr.length();i++){
      if (finalStr[i] == ';'){
         strNum = finalStr.substr(prev, i-prev);
         prev = i + 1;
      }
      if(finalStr[i] == ','){
         repeatNum = std::stoi(finalStr.substr(prev, i-prev));
         for (int j = 0; j < repeatNum;j++){
            strResult.append(strNum);
            strResult.append(",");
         }
         strNum.clear();
         prev = i + 1;
      }
   }
   setData(strResult);
   return true;
};

int StadisticDescriptive::getSize() { return this->_size; };

double StadisticDescriptive::getUnsortedList(int i){
   return this->_unsortedList[i];
};

double StadisticDescriptive::get_x() { return this->_x; };

double StadisticDescriptive::getPopulationVariance(){
   return this->_populationVariance;
}

double StadisticDescriptive::getPopulationDesviation(){
   return this->_populationDeviation;
}
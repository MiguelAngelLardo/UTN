#include <windows.h>

#include <iomanip>
#include <iostream>
#include <regex>

#include "./core/stadistic-descriptive.h"
using namespace std;

void initList() {
   StadisticDescriptive st;
   string values;
   system("cls");
   cout << "ingrese la lista de valores separadas por , o ; " << endl;
   std::getline(cin, values);
   basic_regex rg(
       R"(^\s*([0-9]+(\.[0-9]+)?)(\s*[,;]\s*[0-9]+(\.[0-9]+)?)*\s*[,;]\s*$)");
   if (!regex_match(values, rg)) {
      cout << "valores incorrectamente ingresados" << endl;
      return;
   }
   st.setData(values);
   cout << endl;
   st.showValues();
   st.showTable();
}

void initPair() {
   StadisticDescriptive st;
   string values;
   system("cls");
   cout << "ingrese la lista de pares de valores xi;fi separado por , " << endl;
   std::getline(cin, values);
   basic_regex rg(R"(^\s*[0-9]+(\.[0-9]+)?\s*;\s*[0-9]+(\.[0-9]+)?(\s*,\s*[0-9]+(\.[0-9]+)?\s*;\s*[0-9]+(\.[0-9]+)?)*\s*,\s*$)");
   if (!regex_match(values, rg)) {
      cout << "valores incorrectamente ingresados" << endl;
      return;
   }
   st.setDataDual(values);
   cout << endl;
   st.showValues();
   st.showTable();
}

void initRegresion() {
   StadisticDescriptive st1, st2;
   string value1, value2;
   system("cls");
   cout << "ingrese la primera lista de valores separadas por , o ; " << endl;
   std::getline(cin, value1);
   basic_regex rg(
       R"(^\s*([0-9]+(\.[0-9]+)?)(\s*[,;]\s*[0-9]+(\.[0-9]+)?)*\s*[,;]\s*$)");
   if (!regex_match(value1, rg)) {
      cout << "valores incorrectamente ingresados" << endl;
      return;
   }
   st1.setData(value1);
   cout << endl;
   cout << "ingrese la segunda lista de valores separados por , o ;" << endl;
   std::getline(cin, value2);
   if (!regex_match(value2, rg)) {
      cout << "valores incorrectamente ingresados" << endl;
      return;
   }
   st2.setData(value2);
   if (st2.getSize() != st1.getSize()) {
      cout << "No tienen el mismo tamaño" << endl;
      return;
   }

   double sumatory, covarianze, pendient_m, origin_b, correlation,
       determination;
   sumatory = 0;
   for (int i = 0; i < st2.getSize(); i++) {
      sumatory += st1.getUnsortedList(i) * st2.getUnsortedList(i);
   }
   covarianze = sumatory / st1.getSize() - (st1.get_x() * st2.get_x());
   pendient_m = covarianze / st1.getPopulationVariance();
   origin_b = st2.get_x() - (pendient_m * st1.get_x());
   correlation = covarianze / (st1.getPopulationDesviation() *
                               st2.getPopulationDesviation());
   determination = correlation * correlation * 100;
   cout << endl;
   cout << "Covarianza : " <<std::fixed<< setprecision(6) << covarianze << endl;
   cout << "Pendiente m : " <<std::fixed<< setprecision(6) << pendient_m << endl;
   cout << "Ordenada al origen b : " <<std::fixed<< setprecision(6) << origin_b << endl;
   cout << "Correlacion : " <<std::fixed<< setprecision(6) << correlation << endl;
   cout << "Determinacion : " <<std::fixed<< setprecision(6) << determination << "%"
        << endl;
}

int main() {
   system("cls");
   // Crear una instancia de la clase StadisticDescriptive
   string option;
   cout << "bienvenido a la calculadora de estadistica en C++" << endl;
   while (true) {
      cout << "Elija una forma de cargar los datos: " << endl;
      cout << "-1) muestra por lista de valores separados por cualquier "
              "separador"
           << endl;
      cout << "-2) muestra por pares de valores Xi;fi separados por coma "
           << endl;
      cout << "-3) Regresion Lineal :)"
           << endl;
      cout << "-4) Salir" << endl;
      cout << "opcion a elejir : ";
      getline(cin, option);
      if (option == "1") {
         initList();
         cout << endl << endl;
         system("pause");
         system("cls");
      } else if (option == "2") {
         initPair();
         cout << endl << endl;
         system("pause");
         system("cls");
      } else if (option == "3") {
         initRegresion();
         cout << endl << endl;
         system("pause");
         system("cls");
      } else if (option == "4") {
         break;
      } else {
         cout << endl << "Opcion incorrecta " << endl;
         system("pause");
         system("cls");
      }
   }
   cout << "Gracias por usar la Calculadora de C++ para estadistica" << endl;
   system("pause");
}